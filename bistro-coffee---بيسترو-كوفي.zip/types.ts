
export type UserRole = 'admin' | 'cashier' | 'user';

export interface User {
  id: string;
  name: string;
  phone: string;
  email?: string;
  role: UserRole;
  stamps: number;
  points: number;
  membershipStatus: 'new' | 'gold' | 'admin';
}

export interface Category {
  id: string;
  name: string;
}

export interface Product {
  id: string;
  categoryId: string;
  name: string;
  price: number;
  image: string;
  description?: string;
}

export type OrderStatus = 'received' | 'preparing' | 'ready' | 'delivered' | 'rejected';

export interface Order {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  userPoints?: number;
  items: { productId: string; name: string; quantity: number; price: number }[];
  total: number;
  status: OrderStatus;
  createdAt: number;
  orderCode: string;
}

export interface Offer {
  id: string;
  title: string;
  image: string;
}

export interface GalleryItem {
  id: string;
  url: string;
  type: 'image' | 'video';
  title?: string;
}

export interface StoreInfo {
  logo: string;
  phone: string;
  whatsapp: string;
  instagram: string;
  facebook: string;
  tiktok: string;
  gps: string;
  cardBg?: string;
  workingHours: {
    weekdays: string;
    friday: string;
    saturday: string;
  };
}
