
import { Category, Product, Offer, StoreInfo } from './types';

export const COLORS = {
  primary: '#3d2b1f', // Dark Coffee
  secondary: '#c5a059', // Gold
  accent: '#f5e6d3', // Beige
  white: '#ffffff',
  text: '#1a1a1a',
};

export const INITIAL_CATEGORIES: Category[] = [
  { id: '1', name: 'مشروبات ساخنة' },
  { id: '2', name: 'مشروبات باردة' },
  { id: '3', name: 'حلويات' },
  { id: '4', name: 'مخبوزات' },
];

export const INITIAL_PRODUCTS: Product[] = [
  { id: 'p1', categoryId: '1', name: 'قهوة عربية', price: 25, image: 'https://picsum.photos/400/300?random=1' },
  { id: 'p2', categoryId: '1', name: 'كابتشينو', price: 18, image: 'https://picsum.photos/400/300?random=2' },
  { id: 'p3', categoryId: '2', name: 'آيس لاتيه', price: 20, image: 'https://picsum.photos/400/300?random=3' },
  { id: 'p4', categoryId: '3', name: 'تشيز كيك تمر', price: 30, image: 'https://picsum.photos/400/300?random=4' },
  { id: 'p5', categoryId: '4', name: 'كرواسون زعفران', price: 15, image: 'https://picsum.photos/400/300?random=5' },
];

export const INITIAL_OFFERS: Offer[] = [
  { id: 'o1', title: 'قهوتك الصباحية مجاناً مع كل حلى', image: 'https://picsum.photos/800/400?random=10' },
  { id: 'o2', title: 'خصم 20% على المجموعات العائلية', image: 'https://picsum.photos/800/400?random=11' },
];

export const INITIAL_STORE_INFO: StoreInfo = {
  logo: 'https://picsum.photos/200/200?random=100',
  phone: '+974 5555 1111',
  whatsapp: '+974 5555 1111',
  instagram: '@bistrocoffee.qa',
  facebook: 'bistrocoffee.qa',
  tiktok: '@bistrocoffee.qa',
  gps: 'https://maps.google.com/?q=Doha,Qatar',
  workingHours: {
    weekdays: 'من 6:00 صباحاً إلى 11:00 مساءً',
    friday: 'من 1:00 ظهراً إلى 12:00 منتصف الليل',
    saturday: 'من 7:00 صباحاً إلى 11:30 مساءً'
  }
};
