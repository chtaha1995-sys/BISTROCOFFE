
import React, { useState, useEffect, useRef } from 'react';
import { HashRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { 
  Home, 
  Coffee, 
  ShoppingBag, 
  Store, 
  Image as ImageIcon, 
  QrCode, 
  Settings, 
  ChevronRight, 
  Plus, 
  Trash2, 
  Edit, 
  Bell,
  MessageCircle,
  LogOut,
  Camera,
  X,
  Users,
  CheckCircle2,
  Clock,
  Send,
  Zap,
  Save,
  ChevronLeft,
  ClipboardList,
  LayoutGrid,
  Star,
  Award,
  Phone,
  ArrowRight,
  MapPin,
  Instagram,
  Facebook,
  Monitor,
  UserPlus,
  LogIn
} from 'lucide-react';

import { 
  User as UserType, 
  Product, 
  Category, 
  Order, 
  OrderStatus, 
  Offer, 
  StoreInfo, 
  UserRole,
  GalleryItem 
} from './types';
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS, INITIAL_OFFERS, INITIAL_STORE_INFO } from './constants';

// --- Utility Components ---

const Button: React.FC<{ 
  onClick?: () => void; 
  className?: string; 
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost';
  children: React.ReactNode;
  disabled?: boolean;
  type?: 'button' | 'submit';
}> = ({ onClick, className = '', variant = 'primary', children, disabled, type = 'button' }) => {
  const variants = {
    primary: `bg-[#3d2b1f] text-white hover:bg-[#2a1d15] shadow-lg border-t border-white/10`,
    secondary: `bg-gradient-to-br from-[#c5a059] to-[#b08d4a] text-white shadow-lg border-t border-white/20`,
    outline: `border-2 border-[#c5a059] text-[#c5a059] hover:bg-[#fcf7ed]`,
    danger: `bg-red-500 text-white hover:bg-red-600 shadow-md`,
    ghost: `bg-transparent text-gray-500 hover:bg-gray-100`
  };

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={`px-6 py-3 rounded-2xl font-bold transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 ${variants[variant]} ${className} modern-3d-button`}
    >
      {children}
    </button>
  );
};

const Header: React.FC<{ 
  title: string; 
  showBack?: boolean; 
  onBack?: () => void;
  cartCount?: number;
}> = ({ title, showBack, onBack, cartCount = 0 }) => {
  const navigate = useNavigate();
  return (
    <div className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 bg-white/90 backdrop-blur-md border-b border-[#f5e6d3] shadow-sm">
      <div className="flex items-center gap-3">
        {showBack && (
          <button onClick={onBack} className="p-1.5 rounded-full hover:bg-gray-100 transition-colors">
            <ChevronRight className="w-6 h-6 rotate-180" />
          </button>
        )}
        <h1 className="text-xl font-bold text-[#3d2b1f] heritage-font tracking-wide">{title}</h1>
      </div>
      
      <div className="flex items-center gap-4">
        <button 
          onClick={() => navigate('/cart')}
          className="relative p-2.5 bg-[#fcf7ed] rounded-2xl text-[#3d2b1f] shadow-inner transition-transform active:scale-90"
        >
          <ShoppingBag className="w-5 h-5" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[9px] w-5 h-5 flex items-center justify-center rounded-full border-2 border-white font-bold animate-bounce shadow-md">
              {cartCount}
            </span>
          )}
        </button>
        <div className="w-10 h-10 overflow-hidden rounded-2xl border-2 border-[#c5a059] shadow-md">
          <img src="https://picsum.photos/100/100?random=logo" alt="logo" className="w-full h-full object-cover" />
        </div>
      </div>
    </div>
  );
};

// --- Authentication Portal ---

const AuthPortal: React.FC<{ onAuth: (user: UserType) => void }> = ({ onAuth }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(!phone) return;
    let role: UserRole = 'user';
    if(phone === '000') role = 'admin';
    else if(phone === '111') role = 'cashier';
    
    const u: UserType = { 
      id: Date.now().toString(), 
      phone, 
      name: role === 'user' ? (name || 'ضيف بيسترو') : role.toUpperCase(), 
      role, 
      stamps: 0, 
      points: 0, 
      membershipStatus: 'new' 
    };
    onAuth(u);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-8 bg-[#fdfaf6] relative overflow-hidden">
      <div className="bg-illustration"></div>
      
      {/* Decorative Blur Backgrounds */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#c5a059]/10 rounded-full blur-[100px]"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#3d2b1f]/5 rounded-full blur-[100px]"></div>

      <div className="w-full max-w-sm z-10 space-y-10 animate-in fade-in slide-in-from-bottom-10 duration-1000">
        <div className="text-center space-y-4">
          <div className="w-28 h-28 bg-[#3d2b1f] rounded-[40px] flex items-center justify-center border-4 border-[#c5a059] mx-auto shadow-2xl ring-8 ring-white/50 transition-all hover:scale-105 active:rotate-3">
            <Coffee className="text-[#c5a059] w-14 h-14" />
          </div>
          <div>
            <h1 className="text-4xl font-black text-[#3d2b1f] heritage-font tracking-tighter">بيسترو كوفي</h1>
            <p className="text-[#c5a059] font-bold text-[10px] uppercase tracking-[5px] mt-2">Specialty Coffee Experience</p>
          </div>
        </div>

        <div className="bg-white/90 backdrop-blur-2xl p-10 rounded-[56px] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.15)] border border-white/50 space-y-8">
          <div className="flex bg-[#fcf7ed] p-1.5 rounded-[28px] shadow-inner">
            <button 
              onClick={() => setIsRegister(false)}
              className={`flex-1 py-4 rounded-[22px] text-xs font-black transition-all flex items-center justify-center gap-2 ${!isRegister ? 'bg-[#3d2b1f] text-white shadow-xl' : 'text-gray-400 hover:text-[#3d2b1f]'}`}
            >
              <LogIn className="w-4 h-4" /> تسجيل الدخول
            </button>
            <button 
              onClick={() => setIsRegister(true)}
              className={`flex-1 py-4 rounded-[22px] text-xs font-black transition-all flex items-center justify-center gap-2 ${isRegister ? 'bg-[#3d2b1f] text-white shadow-xl' : 'text-gray-400 hover:text-[#3d2b1f]'}`}
            >
              <UserPlus className="w-4 h-4" /> عضو جديد
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="relative group">
              <Phone className="absolute left-6 top-1/2 -translate-y-1/2 text-[#c5a059] w-5 h-5 opacity-40 group-focus-within:opacity-100 transition-opacity" />
              <input 
                required
                type="tel" 
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="رقم الجوال" 
                className="w-full p-6 pl-16 bg-white border-2 border-[#f5e6d3] rounded-[28px] shadow-inner focus:ring-4 focus:ring-[#c5a059]/20 outline-none transition-all font-bold text-lg text-center" 
              />
            </div>
            
            {isRegister && (
              <div className="relative group animate-in slide-in-from-top-4 fade-in duration-300">
                <Users className="absolute left-6 top-1/2 -translate-y-1/2 text-[#c5a059] w-5 h-5 opacity-40 group-focus-within:opacity-100 transition-opacity" />
                <input 
                  required
                  type="text" 
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="الاسم الكامل" 
                  className="w-full p-6 pl-16 bg-white border-2 border-[#f5e6d3] rounded-[28px] shadow-inner focus:ring-4 focus:ring-[#c5a059]/20 outline-none transition-all font-bold text-center" 
                />
              </div>
            )}

            <Button type="submit" className="w-full py-6 text-xl rounded-[28px] shadow-2xl mt-4">
              {isRegister ? 'انضم إلينا الآن' : 'دخول'}
            </Button>
          </form>

          <div className="text-center">
            <p className="text-[10px] text-gray-400 font-medium leading-relaxed max-w-[200px] mx-auto">
              بالمتابعة أنت تنضم رسمياً لمجتمع بيسترو كوفي المرموق في الدوحة
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- HomePage Components ---

const StoriesBar: React.FC<{ items: GalleryItem[], userRole: UserRole }> = ({ items, userRole }) => {
  const navigate = useNavigate();
  return (
    <div className="px-6 pt-8 mb-4 overflow-x-auto no-scrollbar flex gap-5 items-center">
      {/* Add Story Button (For Admin/Cashier) */}
      {['admin', 'cashier'].includes(userRole) && (
        <div className="flex flex-col items-center gap-2 group cursor-pointer" onClick={() => navigate('/gallery-manager')}>
           <div className="w-[72px] h-[72px] rounded-full p-1 border-2 border-dashed border-[#c5a059] flex items-center justify-center bg-[#fcf7ed] group-active:scale-90 transition-transform">
             <div className="w-full h-full rounded-full bg-white flex items-center justify-center shadow-inner">
               <Plus className="w-6 h-6 text-[#c5a059]" />
             </div>
           </div>
           <span className="text-[9px] font-black text-[#c5a059] uppercase tracking-tighter">أضف قصة</span>
        </div>
      )}

      {/* Actual Stories */}
      {items.length === 0 && !['admin', 'cashier'].includes(userRole) && (
        <div className="flex items-center gap-3 opacity-30 bg-gray-100 p-3 rounded-full pr-6">
          <ImageIcon className="w-6 h-6 text-gray-400" />
          <span className="text-xs font-bold text-gray-400">لا توجد قصص حالياً</span>
        </div>
      )}

      {items.map((item) => (
        <div key={item.id} className="flex flex-col items-center gap-2 cursor-pointer group" onClick={() => navigate('/gallery')}>
           <div className="w-[72px] h-[72px] rounded-full p-[3px] bg-gradient-to-tr from-[#c5a059] to-[#3d2b1f] shadow-lg active:scale-95 transition-transform overflow-hidden">
             <div className="w-full h-full rounded-full bg-white p-[2px]">
               <img src={item.url} className="w-full h-full object-cover rounded-full" alt="story" />
             </div>
           </div>
           <span className="text-[9px] font-bold text-[#3d2b1f] truncate w-16 text-center">{item.title || 'لحظة بيسترو'}</span>
        </div>
      ))}
    </div>
  );
};

const HomePage: React.FC<{ user: UserType; offers: Offer[]; storeInfo: StoreInfo; galleryItems: GalleryItem[] }> = ({ user, offers, storeInfo, galleryItems }) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const navigate = useNavigate();
  const qrData = `BISTRO:${user.phone}:${user.name}`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrData)}&color=3d2b1f&bgcolor=ffffff`;

  return (
    <div className="pb-32">
      <StoriesBar items={galleryItems} userRole={user.role} />

      <div className="px-6 mb-8">
        <div className="flex overflow-x-auto gap-4 no-scrollbar slider-snap">
          {offers.map(o => (
            <div key={o.id} className="min-w-[320px] h-52 rounded-[48px] overflow-hidden relative shadow-2xl group slider-item">
              <img src={o.image} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-8">
                <p className="text-white text-lg font-black leading-tight drop-shadow-lg">{o.title}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="px-6 space-y-10">
        <div className="relative group">
           <div className="absolute -inset-1 bg-gradient-to-r from-[#c5a059] to-[#3d2b1f] rounded-[44px] blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
           <div className="relative bg-white rounded-[44px] shadow-2xl overflow-hidden border border-[#f5e6d3]">
              <div className="p-7">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <h3 className="text-[#3d2b1f] font-black text-2xl heritage-font leading-tight">طلبك يسبقك بخطوة</h3>
                    <p className="text-[#c5a059] text-[10px] font-bold uppercase tracking-[3px] mt-1">Order Ahead & Save Time</p>
                  </div>
                  <div className="w-16 h-16 bg-[#fcf7ed] rounded-[28px] flex items-center justify-center text-[#3d2b1f] shadow-inner">
                    <Zap className="w-9 h-9 animate-pulse text-[#c5a059]" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-5">
                  <button onClick={() => navigate('/menu')} className="flex flex-col items-center justify-center p-6 bg-[#3d2b1f] rounded-[32px] text-white shadow-xl active:scale-95 transition-all gap-2 border-t border-white/10">
                    <Coffee className="w-7 h-7 text-[#c5a059]" />
                    <span className="text-[11px] font-black">طلب من المنيو</span>
                  </button>
                  <a href={`https://wa.me/${storeInfo.whatsapp.replace(/\s+/g, '')}?text=مرحباً، أريد القيام بطلب مسبق`} className="flex flex-col items-center justify-center p-6 bg-green-500 rounded-[32px] text-white shadow-xl active:scale-95 transition-all gap-2 border-t border-white/20">
                    <MessageCircle className="w-7 h-7" />
                    <span className="text-[11px] font-black">واتساب سريع</span>
                  </a>
                </div>
              </div>
           </div>
        </div>

        {/* Loyalty Card */}
        <div className="perspective-1000 flex justify-center" onClick={() => setIsFlipped(!isFlipped)}>
          <div className={`relative w-[350px] h-[230px] card-inner ${isFlipped ? 'card-flipped' : ''} cursor-pointer`}>
            {/* Front Card */}
            <div className="absolute inset-0 card-face w-full h-full bg-[#3d2b1f] rounded-[48px] shadow-2xl p-8 flex flex-col justify-between border-2 border-white/10 overflow-hidden" style={{ backgroundImage: storeInfo.cardBg ? `url(${storeInfo.cardBg})` : 'none', backgroundSize: 'cover', backgroundPosition: 'center' }}>
              <div className="flex justify-between items-start z-10">
                <div className="text-[#c5a059]">
                  <h3 className="font-black heritage-font text-2xl tracking-tighter drop-shadow-2xl">Bistro Coffee</h3>
                  <div className="flex items-center gap-1.5 mt-1 opacity-90"><Star className="w-3 h-3 fill-current" /><p className="text-[9px] tracking-[5px] uppercase font-black">LOYALTY MEMBER</p></div>
                </div>
                <div className="bg-white p-2.5 rounded-2xl shadow-2xl border-2 border-[#c5a059]/30 transition-transform hover:scale-110"><img src={qrUrl} alt="User QR" className="w-16 h-16 rounded-lg" /></div>
              </div>
              <div className="z-10 bg-black/40 backdrop-blur-xl p-4 px-6 rounded-2xl inline-block w-fit shadow-xl border border-white/10">
                <p className="text-white text-xl font-black tracking-wide leading-none">{user.name}</p>
                <p className="text-[#c5a059] text-[11px] font-mono font-bold mt-2 tracking-[2px]">{user.phone}</p>
              </div>
              <div className="flex justify-between items-end z-10">
                <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-green-500 shadow-[0_0_15px_#22c55e] animate-pulse"></div><p className="text-[#c5a059] font-black text-[10px] tracking-[2px] uppercase">Active Member</p></div>
                <div className="flex flex-col items-end"><div className="w-14 h-9 bg-gradient-to-br from-yellow-200 via-yellow-400 to-yellow-700 rounded-xl shadow-lg ring-1 ring-white/30"></div></div>
              </div>
              {storeInfo.cardBg && <div className="absolute inset-0 bg-black/50 -z-1"></div>}
            </div>
            {/* Back Card */}
            <div className="absolute inset-0 card-face card-back w-full h-full bg-[#fdfaf6] rounded-[48px] shadow-2xl p-8 flex flex-col border-2 border-[#c5a059]/30 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-48 h-48 bg-[#c5a059]/5 rounded-full -translate-x-24 -translate-y-24"></div>
              <h4 className="text-[#3d2b1f] font-black mb-6 text-center text-sm heritage-font uppercase tracking-widest border-b border-[#c5a059]/20 pb-2">سجل المكافآت</h4>
              <div className="grid grid-cols-5 gap-4 mb-6">
                {[...Array(10)].map((_, i) => {
                  const isActive = i < user.stamps;
                  const isFree = i === 9;
                  return (
                    <div key={i} className={`h-12 rounded-2xl border-2 flex items-center justify-center transition-all duration-700 relative ${isFree ? `free-cup-frame ${isActive ? 'golden-glow bg-gradient-to-br from-yellow-300 to-yellow-600 scale-125 z-10' : 'opacity-100'}` : (isActive ? 'bg-[#3d2b1f] border-[#c5a059] shadow-xl scale-110' : 'bg-gray-100/50 border-gray-200/40 dashed-border')}>`}>
                      {isFree ? (<div className="flex flex-col items-center"><Coffee className={`w-5 h-5 ${isActive ? 'text-white' : 'text-[#c5a059]'} ${!isActive ? 'animate-pulse' : ''}`} /><span className={`text-[6px] font-black ${isActive ? 'text-white' : 'text-[#c5a059]'} uppercase mt-0.5`}>مجاناً</span></div>) : (isActive ? (<Coffee className="w-6 h-6 text-[#c5a059]" />) : (<div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>))}
                      {isActive && !isFree && (<div className="absolute -top-1 -right-1 bg-green-500 rounded-full p-0.5 border border-white shadow-sm"><CheckCircle2 className="w-2 h-2 text-white" /></div>)}
                    </div>
                  );
                })}
              </div>
              <div className="mt-auto space-y-3">
                <div className="flex justify-between text-[11px] font-black text-[#3d2b1f]"><span className="opacity-50 tracking-wider">تقدمك نحو الهدية</span><span className="text-[#c5a059] tracking-tighter">{user.stamps} / 10 أكواب</span></div>
                <div className="w-full h-3 bg-gray-200/40 rounded-full overflow-hidden p-0.5 shadow-inner"><div className="h-full bg-gradient-to-r from-[#c5a059] to-[#b08d4a] rounded-full transition-all duration-1000 shadow-sm" style={{ width: `${(user.stamps / 10) * 100}%` }}></div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Gallery Components ---

const GalleryPage: React.FC<{ items: GalleryItem[] }> = ({ items }) => {
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);
  const navigate = useNavigate();

  return (
    <div className="pb-32 px-6 pt-6 animate-in fade-in duration-500">
      <Header title="لحظات بيسترو" showBack onBack={() => navigate('/')} />
      {items.length === 0 ? (
        <div className="py-32 text-center text-gray-300">
          <ImageIcon className="w-24 h-24 mx-auto opacity-10 mb-8" />
          <p className="font-bold">المعرض فارغ حالياً</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-5 mt-8">
          {items.map((item) => (
            <div 
              key={item.id} 
              onClick={() => setSelectedItem(item)}
              className="aspect-[9/16] rounded-[40px] overflow-hidden relative border-2 border-[#f5e6d3] shadow-lg cursor-pointer active:scale-95 transition-all group"
            >
              <img src={item.url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt={item.title} />
              {item.type === 'video' && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                  <Monitor className="w-10 h-10 text-white opacity-70" />
                </div>
              )}
              <div className="absolute bottom-0 left-0 right-0 p-5 bg-gradient-to-t from-black/80 to-transparent">
                <p className="text-white text-[11px] font-black truncate">{item.title || 'بيسترو'}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {selectedItem && (
        <div className="fixed inset-0 z-[100] bg-black flex items-center justify-center p-4">
          <button 
            onClick={() => setSelectedItem(null)}
            className="absolute top-10 right-8 z-[110] p-4 bg-white/20 rounded-full text-white backdrop-blur-xl active:scale-90"
          >
            <X className="w-7 h-7" />
          </button>
          <div className="w-full max-w-sm aspect-[9/16] rounded-[56px] overflow-hidden shadow-2xl relative">
            {selectedItem.type === 'image' ? (
              <img src={selectedItem.url} className="w-full h-full object-cover" alt={selectedItem.title} />
            ) : (
              <video src={selectedItem.url} className="w-full h-full object-cover" controls autoPlay loop />
            )}
            {selectedItem.title && (
              <div className="absolute bottom-0 left-0 right-0 p-10 bg-gradient-to-t from-black/95 via-black/40 to-transparent">
                <h3 className="text-white text-2xl font-black heritage-font tracking-tight">{selectedItem.title}</h3>
                <p className="text-white/60 text-xs mt-2">بيسترو كوفي - تجربة فريدة</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const GalleryManager: React.FC<{ items: GalleryItem[], setItems: (items: GalleryItem[]) => void }> = ({ items, setItems }) => {
  const [showForm, setShowForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if(!newUrl) return;
    const newItem: GalleryItem = {
      id: Date.now().toString(),
      url: newUrl,
      type: newUrl.includes('.mp4') || newUrl.includes('video') ? 'video' : 'image',
      title: newTitle || 'قصة جديدة'
    };
    setItems([...items, newItem]);
    setNewTitle('');
    setNewUrl('');
    setShowForm(false);
  };

  return (
    <div className="p-6 space-y-8 pb-32">
      <Header title="إدارة المعرض" showBack onBack={() => window.history.back()} />
      
      <Button className="w-full py-6 shadow-2xl text-lg" onClick={() => setShowForm(true)}>
        <Plus className="w-6 h-6" /> إضافة قصة جديدة
      </Button>

      {showForm && (
        <div className="fixed inset-0 z-[100] bg-[#3d2b1f]/60 backdrop-blur-md flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-sm rounded-[48px] p-8 shadow-2xl space-y-6 animate-in zoom-in-95 duration-300">
            <div className="flex justify-between items-center">
              <h3 className="font-black text-[#3d2b1f] text-lg">إضافة محتوى</h3>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 rounded-full"><X /></button>
            </div>
            <form onSubmit={handleAddItem} className="space-y-4">
              <input 
                required
                type="text" 
                placeholder="رابط الصورة أو الفيديو" 
                value={newUrl}
                onChange={e => setNewUrl(e.target.value)}
                className="w-full p-5 border-2 border-gray-100 rounded-2xl focus:border-[#c5a059] outline-none font-bold text-sm"
              />
              <input 
                type="text" 
                placeholder="عنوان القصة" 
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                className="w-full p-5 border-2 border-gray-100 rounded-2xl focus:border-[#c5a059] outline-none font-bold text-sm"
              />
              <Button type="submit" className="w-full py-4 rounded-2xl">تأكيد الإضافة</Button>
            </form>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-5">
        {items.map((item) => (
          <div key={item.id} className="aspect-[9/16] rounded-[36px] overflow-hidden relative border-2 border-[#f5e6d3] shadow-md">
            <img src={item.url} className="w-full h-full object-cover" alt="preview" />
            <div className="absolute top-3 right-3 flex gap-2">
              <button onClick={() => setItems(items.filter(x => x.id !== item.id))} className="p-2.5 bg-red-600 text-white rounded-2xl shadow-xl active:scale-90">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold">
              {item.title}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- Store Info Page ---

const StoreInfoPage: React.FC<{ storeInfo: StoreInfo }> = ({ storeInfo }) => {
  return (
    <div className="pb-32 px-6 pt-6 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col items-center gap-6">
        <div className="w-36 h-36 rounded-[48px] border-4 border-[#c5a059] overflow-hidden shadow-2xl p-2.5 bg-white flex items-center justify-center transition-transform hover:scale-105">
          <img src={storeInfo.logo} className="w-full h-full object-cover rounded-[38px]" alt="Bistro Logo" />
        </div>
        <div className="text-center">
          <h2 className="text-4xl font-black text-[#3d2b1f] heritage-font tracking-tighter">بيسترو كوفي</h2>
          <p className="text-[#c5a059] font-bold text-xs uppercase tracking-[4px] mt-2">Specialty Coffee & Qatari Heritage</p>
        </div>
      </div>

      <div className="bg-white rounded-[44px] p-8 shadow-xl border border-[#f5e6d3] space-y-6">
        <h3 className="font-black text-[#3d2b1f] text-lg border-b border-gray-100 pb-5 flex items-center gap-3">
          <Clock className="w-6 h-6 text-[#c5a059]" /> أوقات العمل الرسمية
        </h3>
        <div className="space-y-4">
          {[
            { day: 'الأحد - الخميس', time: storeInfo.workingHours.weekdays },
            { day: 'الجمعة', time: storeInfo.workingHours.friday },
            { day: 'السبت', time: storeInfo.workingHours.saturday }
          ].map((h, i) => (
            <div key={i} className="flex justify-between items-center bg-gray-50/50 p-5 rounded-3xl border border-gray-100">
              <span className="font-black text-[#3d2b1f] text-sm">{h.day}</span>
              <span className="text-[#c5a059] text-[11px] font-black">{h.time}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-5">
        <a href={storeInfo.gps} target="_blank" rel="noreferrer" className="bg-white p-7 rounded-[40px] border border-[#f5e6d3] flex flex-col items-center gap-4 shadow-md active:scale-95 transition-all group">
          <div className="p-4 bg-[#fcf7ed] rounded-3xl text-[#c5a059] group-hover:scale-110 transition-transform"><MapPin className="w-8 h-8" /></div>
          <span className="text-[11px] font-black text-[#3d2b1f]">موقعنا (GPS)</span>
        </a>
        <a href={`tel:${storeInfo.phone.replace(/\s+/g, '')}`} className="bg-white p-7 rounded-[40px] border border-[#f5e6d3] flex flex-col items-center gap-4 shadow-md active:scale-95 transition-all group">
          <div className="p-4 bg-[#fcf7ed] rounded-3xl text-[#c5a059] group-hover:scale-110 transition-transform"><Phone className="w-8 h-8" /></div>
          <span className="text-[11px] font-black text-[#3d2b1f]">اتصال مباشر</span>
        </a>
      </div>

      <div className="bg-[#3d2b1f] rounded-[48px] p-10 text-white shadow-2xl space-y-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-20 translate-x-20"></div>
        <h3 className="font-bold heritage-font text-2xl text-[#c5a059] relative z-10 border-b border-white/10 pb-4">تواصل معنا</h3>
        <div className="grid grid-cols-3 gap-8 relative z-10">
          {[
            { icon: <MessageCircle className="w-7 h-7" />, color: 'bg-green-500', label: 'واتساب', link: `https://wa.me/${storeInfo.whatsapp.replace(/\s+/g, '').replace('+', '')}` },
            { icon: <Instagram className="w-7 h-7" />, color: 'bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600', label: 'انستقرام', link: `https://instagram.com/${storeInfo.instagram.replace('@','')}` },
            { icon: <Monitor className="w-7 h-7" />, color: 'bg-black border border-white/20', label: 'تيك توك', link: `https://tiktok.com/@${storeInfo.tiktok.replace('@','')}` }
          ].map((s, i) => (
            <a key={i} href={s.link} target="_blank" rel="noreferrer" className="flex flex-col items-center gap-3 group">
              <div className={`w-14 h-14 ${s.color} rounded-[22px] flex items-center justify-center group-hover:scale-110 transition-transform shadow-xl`}>{s.icon}</div>
              <span className="text-[9px] font-bold opacity-70">{s.label}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};

// --- Shared Components for Nav ---

const NavItem: React.FC<{ to: string; icon: React.ReactNode; label: string; activeColor?: string }> = ({ to, icon, label, activeColor = 'text-[#3d2b1f]' }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const isActive = location.pathname === to;
  return (
    <button onClick={() => navigate(to)} className={`flex flex-col items-center gap-1.5 transition-all duration-300 ${isActive ? `${activeColor} scale-110 font-bold` : 'text-gray-400 hover:text-gray-500'}`}>
      <div className={`p-2.5 ${isActive ? 'bg-[#fcf7ed] rounded-2xl shadow-inner' : ''}`}>{React.cloneElement(icon as React.ReactElement<any>, { className: 'w-6 h-6' })}</div>
      <span className="text-[10px] tracking-tighter font-black">{label}</span>
    </button>
  );
};

// --- Other Admin Pages ---

const MenuManager = ({ categories, setCategories, products, setProducts }: any) => (
  <div className="p-6 space-y-6 pb-32">
    <Header title="تعديل المنيو" showBack onBack={() => window.history.back()} />
    <Button className="w-full py-5 shadow-xl" onClick={() => {
      const name = prompt("اسم القسم الجديد:");
      if(name) setCategories([...categories, { id: Date.now().toString(), name }]);
    }}><Plus /> إضافة قسم</Button>
    {categories.map((cat: any) => (
      <div key={cat.id} className="bg-white p-6 rounded-[36px] border-2 border-[#f5e6d3] space-y-5 shadow-sm">
        <div className="flex justify-between items-center"><h3 className="font-black text-lg text-[#3d2b1f]">{cat.name}</h3><button onClick={() => setCategories(categories.filter((c: any) => c.id !== cat.id))} className="text-red-400 p-2"><Trash2 className="w-5 h-5" /></button></div>
        <div className="space-y-3">
          {products.filter((p: any) => p.categoryId === cat.id).map((p: any) => (
            <div key={p.id} className="flex items-center gap-4 bg-gray-50/50 p-4 rounded-3xl border border-gray-100">
              <img src={p.image} className="w-14 h-14 rounded-2xl object-cover shadow-sm" />
              <div className="flex-grow text-xs font-black text-[#3d2b1f]">{p.name} - {p.price} ر.ق</div>
              <button onClick={() => setProducts(products.filter((x: any) => x.id !== p.id))} className="text-red-400 p-3 bg-white rounded-2xl shadow-sm"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
          <Button variant="ghost" className="w-full text-xs border-2 border-dashed border-gray-200 py-4 rounded-2xl" onClick={() => {
            const name = prompt("اسم المنتج:");
            const price = prompt("السعر:");
            const image = prompt("رابط الصورة:");
            if(name && price) setProducts([...products, { id: Date.now().toString(), categoryId: cat.id, name, price: parseFloat(price), image: image || 'https://picsum.photos/200' }]);
          }}>+ إضافة منتج جديد</Button>
        </div>
      </div>
    ))}
  </div>
);

const SliderManager = ({ offers, setOffers }: any) => (
  <div className="p-6 space-y-6 pb-32">
    <Header title="إدارة السلايدر" showBack onBack={() => window.history.back()} />
    <Button className="w-full py-5 shadow-xl" onClick={() => {
      const title = prompt("عنوان العرض:");
      const image = prompt("رابط الصورة:");
      if(title && image) setOffers([...offers, { id: Date.now().toString(), title, image }]);
    }}><Plus /> إضافة عرض جديد</Button>
    <div className="grid grid-cols-1 gap-5">
      {offers.map((o: any) => (
        <div key={o.id} className="bg-white p-5 rounded-[36px] border-2 border-[#f5e6d3] flex items-center gap-5 shadow-sm relative overflow-hidden">
          <img src={o.image} className="w-24 h-24 rounded-3xl object-cover shadow-md" />
          <span className="flex-grow text-xs font-black text-[#3d2b1f]">{o.title}</span>
          <button onClick={() => setOffers(offers.filter((x: any) => x.id !== o.id))} className="text-red-500 p-3 bg-red-50 rounded-2xl transition-all hover:bg-red-100"><Trash2 className="w-6 h-6" /></button>
        </div>
      ))}
    </div>
  </div>
);

const OrderHistoryPage: React.FC<{ orders: Order[] }> = ({ orders }) => {
  return (
    <div className="p-6 space-y-6 pb-32">
      <Header title="سجل الطلبات" showBack onBack={() => window.history.back()} />
      <div className="bg-[#fcf7ed] p-5 rounded-3xl border border-[#f5e6d3] flex items-start gap-4 shadow-inner">
        <Clock className="w-6 h-6 text-[#c5a059] mt-1" />
        <p className="text-[11px] text-[#3d2b1f] leading-relaxed font-bold">يتم الاحتفاظ بسجلات الطلبات لمدة 60 يوماً فقط للحفاظ على خصوصية البيانات.</p>
      </div>
      {orders.length === 0 ? (
        <div className="py-24 text-center text-gray-300 font-bold flex flex-col items-center gap-4">
          <Trash2 className="w-16 h-16 opacity-10" />
          <span>السجل فارغ حالياً</span>
        </div>
      ) : (
        orders.slice().reverse().map(o => (
          <div key={o.id} className="bg-white p-6 rounded-[40px] border border-[#f5e6d3] shadow-sm space-y-4 hover:shadow-lg transition-shadow">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-black text-[#3d2b1f] text-base">{o.userName}</h4>
                <p className="text-xs text-[#c5a059] font-black">{o.userPhone}</p>
                <p className="text-[10px] text-gray-400 mt-2 font-mono">{new Date(o.createdAt).toLocaleString('ar-QA')}</p>
              </div>
              <div className="text-right">
                <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase shadow-sm ${o.status === 'delivered' ? 'bg-green-100 text-green-600' : (o.status === 'rejected' ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-400')}`}>
                  {o.status === 'delivered' ? 'تم التسليم' : (o.status === 'rejected' ? 'مرفوض' : 'قيد العمل')}
                </span>
                <p className="text-[10px] font-bold text-[#3d2b1f] mt-4">النقاط: <span className="text-[#c5a059]">{o.userPoints || 0}</span></p>
              </div>
            </div>
            <div className="text-[11px] text-gray-600 border-t border-dashed border-gray-100 pt-4 flex flex-wrap gap-2">
              <span className="font-bold opacity-50">الطلب:</span>
              {o.items.map((i, idx) => <span key={idx} className="bg-gray-50 px-3 py-1 rounded-xl border border-gray-100">{i.name} ({i.quantity})</span>)}
            </div>
          </div>
        ))
      )}
    </div>
  );
};

const AdminDashboard = ({ onLogout, orders }: any) => {
  const navigate = useNavigate();
  return (
    <div className="p-6 space-y-8 pb-32">
      <Header title="لوحة التحكم" />
      <div className="grid grid-cols-2 gap-5">
        <AdminCard icon={<Coffee />} label="إدارة المنيو" onClick={() => navigate('/menu-manager')} />
        <AdminCard icon={<Bell />} label="السلايدر" onClick={() => navigate('/slider-manager')} />
        <AdminCard icon={<ImageIcon />} label="المعرض" onClick={() => navigate('/gallery-manager')} />
        <AdminCard icon={<ClipboardList />} label="سجل الطلبات" onClick={() => navigate('/order-history')} />
        <AdminCard icon={<Settings />} label="الهوية" onClick={() => navigate('/settings')} />
      </div>
      <div className="bg-gradient-to-br from-[#3d2b1f] to-[#1a110a] p-10 rounded-[56px] text-white shadow-2xl flex items-center justify-between relative overflow-hidden">
        <div className="relative z-10"><h4 className="text-xs opacity-60 font-black mb-2 tracking-widest uppercase">إجمالي الدخل</h4><p className="text-4xl font-black text-[#c5a059] tracking-tighter">{orders.reduce((s:any, o:any) => s + (o.status === 'delivered' ? o.total : 0), 0)} <span className="text-base font-normal">ر.ق</span></p></div>
        <Award className="w-16 h-16 text-[#c5a059] opacity-20 relative z-10" />
        <div className="absolute top-0 left-0 w-32 h-32 bg-white/5 rounded-full -translate-x-16 -translate-y-16"></div>
      </div>
      <Button onClick={onLogout} variant="danger" className="w-full py-6 rounded-[32px] text-lg">تسجيل الخروج</Button>
    </div>
  );
};

const AdminCard = ({ icon, label, onClick }: any) => (
  <button onClick={onClick} className="bg-white p-8 rounded-[48px] border-2 border-[#f5e6d3] flex flex-col items-center gap-5 shadow-sm active:scale-95 transition-all hover:bg-[#fcf7ed] hover:shadow-xl group">
    <div className="p-5 bg-[#fcf7ed] rounded-[28px] text-[#3d2b1f] shadow-inner group-hover:scale-110 transition-transform">{React.cloneElement(icon, { className: 'w-10 h-10' })}</div>
    <span className="text-[13px] font-black text-[#3d2b1f] uppercase tracking-tighter">{label}</span>
  </button>
);

// --- Main App Component ---

export default function App() {
  const [user, setUser] = useState<UserType | null>(null);
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('orders_list_v4');
    let loaded: Order[] = saved ? JSON.parse(saved) : [];
    const TWO_MONTHS_MS = 60 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    return loaded.filter(o => (now - o.createdAt) < TWO_MONTHS_MS);
  });
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('products_list_v4');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });
  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('cats_list_v4');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });
  const [offers, setOffers] = useState<Offer[]>(() => {
    const saved = localStorage.getItem('offers_list_v4');
    return saved ? JSON.parse(saved) : INITIAL_OFFERS;
  });
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(() => {
    const saved = localStorage.getItem('gallery_list_v4');
    return saved ? JSON.parse(saved) : [];
  });
  const [storeInfo, setStoreInfo] = useState<StoreInfo>(() => {
    const saved = localStorage.getItem('store_info_v4');
    return saved ? JSON.parse(saved) : INITIAL_STORE_INFO;
  });
  const [notificationActive, setNotificationActive] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    localStorage.setItem('orders_list_v4', JSON.stringify(orders));
    localStorage.setItem('products_list_v4', JSON.stringify(products));
    localStorage.setItem('cats_list_v4', JSON.stringify(categories));
    localStorage.setItem('offers_list_v4', JSON.stringify(offers));
    localStorage.setItem('gallery_list_v4', JSON.stringify(galleryItems));
    localStorage.setItem('store_info_v4', JSON.stringify(storeInfo));
  }, [orders, products, categories, offers, galleryItems, storeInfo]);

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
      audioRef.current.loop = true;
    }
    const hasReceived = orders.some(o => o.status === 'received');
    if (hasReceived && ['admin', 'cashier'].includes(user?.role || '')) {
      setNotificationActive(true);
      audioRef.current.play().catch(() => {});
    } else {
      setNotificationActive(false);
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  }, [orders, user]);

  const handleProcessAction = (type: 'stamp' | 'redeem', phone: string, val: number) => {
    if (type === 'redeem') {
      alert(`🎉 تم تسليم الهدية للزبون ${phone} وتصفير العداد بنجاح!`);
      if (user && user.phone === phone) {
        const updated = { ...user, stamps: 0 };
        setUser(updated);
        localStorage.setItem('user', JSON.stringify(updated));
      }
    } else {
      const stampsToAdd = Math.max(1, Math.floor(val / 40));
      alert(`✅ تم إضافة ${stampsToAdd} أختام لحساب العميل بنجاح!`);
      if (user && user.phone === phone) {
        const updated = { ...user, stamps: Math.min(user.stamps + stampsToAdd, 10), points: user.points + val };
        setUser(updated);
        localStorage.setItem('user', JSON.stringify(updated));
      }
    }
  };

  useEffect(() => {
    const saved = localStorage.getItem('user');
    if(saved) setUser(JSON.parse(saved));
  }, []);

  if (!user) return <AuthPortal onAuth={(u) => { setUser(u); localStorage.setItem('user', JSON.stringify(u)); }} />;

  return (
    <HashRouter>
      <div className="max-w-md mx-auto min-h-screen bg-[#fdfaf6] shadow-2xl relative overflow-x-hidden border-x border-gray-100 pb-20">
        <div className="bg-illustration"></div>
        
        {notificationActive && (
          <div className="fixed top-0 left-0 right-0 z-[100] bg-red-600 text-white p-6 flex items-center justify-between shadow-2xl animate-pulse">
            <div className="flex items-center gap-4"><Bell className="w-8 h-8 animate-bounce" /><div className="text-xs font-black"><p className="text-base">طلب جديد بانتظارك!</p><p className="opacity-80 font-normal mt-1">يرجى مراجعة الطلبات والرد لإيقاف الرنين</p></div></div>
            <button onClick={() => setNotificationActive(false)} className="p-2.5 bg-white/20 rounded-full active:scale-90"><X className="w-6 h-6" /></button>
          </div>
        )}

        <Routes>
          <Route path="/" element={<><Header title="بيسترو كوفي" cartCount={cart.length} /><HomePage user={user} offers={offers} storeInfo={storeInfo} galleryItems={galleryItems} /></>} />
          <Route path="/menu" element={<><Header title="القائمة" cartCount={cart.length} /><MenuPage categories={categories} products={products} onAddToCart={(p:any) => setCart([...cart, { product: p, quantity: 1 }])} /></>} />
          <Route path="/cart" element={<><Header title="سلتي" showBack onBack={() => window.history.back()} /><CartPage cart={cart} onUpdateQty={(id:any, d:any) => setCart(prev => prev.map(i => i.product.id === id ? {...i, quantity: i.quantity + d} : i).filter(i => i.quantity > 0))} onCheckout={() => {
            const newOrder: Order = {
              id: Math.random().toString(36).substr(2, 9), userId: user.id, userName: user.name, userPhone: user.phone, userPoints: user.points,
              items: cart.map(i => ({ productId: i.product.id, name: i.product.name, quantity: i.quantity, price: i.product.price })),
              total: cart.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
              status: 'received', createdAt: Date.now(), orderCode: Math.random().toString(36).substr(2, 5).toUpperCase(),
            };
            setOrders([...orders, newOrder]); setCart([]); window.location.hash = '#/orders';
          }} /></>} />
          <Route path="/orders" element={<><Header title="طلباتي" cartCount={cart.length} /><OrdersPage orders={orders} userRole={user.role} onUpdateStatus={(id:any, status:any) => setOrders(prev => prev.map(o => o.id === id ? {...o, status} : o))} /></>} />
          <Route path="/scan" element={<><Header title="نظام الولاء" cartCount={cart.length} /><ScannerPage onProcessAction={handleProcessAction} /></>} />
          <Route path="/gallery" element={<GalleryPage items={galleryItems} />} />
          <Route path="/store" element={<><Header title="معلومات المتجر" showBack onBack={() => window.history.back()} /><StoreInfoPage storeInfo={storeInfo} /></>} />
          <Route path="/admin" element={<AdminDashboard onLogout={() => { setUser(null); localStorage.removeItem('user'); }} orders={orders} />} />
          <Route path="/order-history" element={<OrderHistoryPage orders={orders} />} />
          <Route path="/menu-manager" element={<MenuManager categories={categories} setCategories={setCategories} products={products} setProducts={setProducts} />} />
          <Route path="/slider-manager" element={<SliderManager offers={offers} setOffers={setOffers} />} />
          <Route path="/gallery-manager" element={<GalleryManager items={galleryItems} setItems={setGalleryItems} />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>

        <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/95 backdrop-blur-2xl border-t border-[#f5e6d3] px-2 py-5 z-40 flex justify-around items-center rounded-t-[56px] shadow-[0_-20px_60px_rgba(0,0,0,0.12)]">
          <NavItem to="/" icon={<Home />} label="الرئيسية" />
          <NavItem to="/menu" icon={<Coffee />} label="المنيو" />
          {['admin', 'cashier'].includes(user.role) ? (
            <NavItem to="/scan" icon={<QrCode />} label="مسح" activeColor="text-[#c5a059]" />
          ) : (
            <NavItem to="/orders" icon={<ClipboardList />} label="طلباتي" />
          )}
          <NavItem to="/store" icon={<Store />} label="المتجر" />
          {user.role === 'admin' ? (
            <NavItem to="/admin" icon={<Settings />} label="إدارة" activeColor="text-[#c5a059]" />
          ) : (
            <NavItem to="/gallery" icon={<ImageIcon />} label="المعرض" />
          )}
        </nav>
      </div>
    </HashRouter>
  );
}

// --- Placeholder sub-components ---

const MenuPage = ({ categories, products, onAddToCart }: any) => {
  const [activeCat, setActiveCat] = useState(categories[0]?.id || '');
  return (
    <div className="pb-32">
      <div className="sticky top-[73px] z-20 bg-white/95 backdrop-blur-lg flex overflow-x-auto gap-3 px-6 py-5 border-b border-[#f5e6d3] no-scrollbar">
        {categories.map((cat:any) => (
          <button key={cat.id} onClick={() => setActiveCat(cat.id)} className={`whitespace-nowrap px-8 py-3.5 rounded-2xl font-black transition-all ${activeCat === cat.id ? 'bg-[#3d2b1f] text-[#c5a059] shadow-xl' : 'bg-[#fcf7ed] text-gray-400'}`}>{cat.name}</button>
        ))}
      </div>
      <div className="p-6 grid grid-cols-2 gap-6">
        {products.filter((p:any) => p.categoryId === activeCat).map((p:any) => (
          <div key={p.id} className="bg-white rounded-[40px] overflow-hidden border border-[#f5e6d3] flex flex-col shadow-sm hover:shadow-2xl transition-all hover:-translate-y-1 group">
            <div className="h-40 w-full overflow-hidden">
               <img src={p.image} className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-700" />
            </div>
            <div className="p-5 space-y-4 flex-grow flex flex-col justify-between">
              <h3 className="font-black text-sm text-[#3d2b1f] leading-tight h-10 overflow-hidden">{p.name}</h3>
              <Button onClick={() => onAddToCart(p)} className="w-full text-[10px] py-3 rounded-2xl font-black">أضف {p.price} ر.ق</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const CartPage = ({ cart, onUpdateQty, onCheckout }: any) => (
  <div className="p-6 space-y-6 pb-32">
    {cart.length === 0 ? (
      <div className="py-32 text-center text-gray-300"><ShoppingBag className="w-24 h-24 mx-auto opacity-10 mb-8" /><p className="font-black text-lg">سلتك بانتظار مشروبك المفضل</p></div>
    ) : (
      <>
        {cart.map((item: any) => (
          <div key={item.product.id} className="bg-white p-5 rounded-[36px] border border-[#f5e6d3] flex justify-between items-center shadow-sm">
            <div className="flex items-center gap-4">
              <img src={item.product.image} className="w-16 h-16 rounded-[22px] object-cover shadow-md" />
              <div><h4 className="font-black text-sm text-[#3d2b1f]">{item.product.name}</h4><p className="text-[#c5a059] text-xs font-black mt-1">{item.product.price} ر.ق</p></div>
            </div>
            <div className="flex items-center gap-4">
              <button onClick={() => onUpdateQty(item.product.id, -1)} className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center border border-gray-100 shadow-sm active:scale-90 font-black">-</button>
              <span className="font-black text-[#3d2b1f] w-4 text-center">{item.quantity}</span>
              <button onClick={() => onUpdateQty(item.product.id, 1)} className="w-10 h-10 rounded-full bg-[#fcf7ed] flex items-center justify-center border border-[#f5e6d3] text-[#3d2b1f] shadow-sm active:scale-90 font-black">+</button>
            </div>
          </div>
        ))}
        <div className="bg-[#3d2b1f] p-10 rounded-[56px] text-white shadow-2xl relative overflow-hidden mt-10">
           <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full -translate-y-24 translate-x-24"></div>
          <div className="flex justify-between mb-10 items-end relative z-10"><span className="opacity-60 text-xs font-black tracking-widest uppercase">المجموع الكلي</span><span className="font-black text-3xl text-[#c5a059] tracking-tighter">{cart.reduce((sum: number, i: any) => sum + i.product.price * i.quantity, 0)} ر.ق</span></div>
          <Button onClick={onCheckout} className="w-full py-6 text-xl rounded-[28px] relative z-10">تأكيد الطلب الآن</Button>
        </div>
      </>
    )}
  </div>
);

const OrdersPage = ({ orders, userRole, onUpdateStatus }: any) => (
  <div className="p-6 space-y-8 pb-32">
    {orders.length === 0 ? (
      <div className="py-32 text-center text-gray-300"><ClipboardList className="w-24 h-24 mx-auto opacity-10 mb-8" /><p className="font-black">لا توجد طلبات سابقة</p></div>
    ) : (
      orders.filter((o:any) => o.status !== 'delivered' && o.status !== 'rejected').slice().reverse().map((o:any) => (
        <div key={o.id} className="bg-white p-8 rounded-[48px] shadow-lg border border-[#f5e6d3] space-y-6 animate-in slide-in-from-bottom-5 duration-500">
          <div className="flex justify-between items-start">
            <div><h4 className="font-black text-xl text-[#3d2b1f]">{o.userName}</h4><p className="text-[10px] text-gray-400 font-black tracking-[3px] uppercase mt-1">{o.orderCode}</p></div>
            <span className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase ${o.status === 'ready' ? 'bg-green-100 text-green-600 animate-pulse' : (o.status === 'preparing' ? 'bg-[#fcf7ed] text-[#c5a059]' : 'bg-gray-100 text-gray-400')}`}>
              {o.status === 'received' ? 'تم الاستلام' : o.status === 'preparing' ? 'قيد التحضير' : o.status === 'ready' ? 'جاهز للاستلام' : o.status === 'delivered' ? 'تم التسليم' : 'مرفوض'}
            </span>
          </div>
          <div className="text-xs text-gray-600 border-t border-dashed border-gray-100 pt-6 space-y-3">
            {o.items.map((i:any, idx:number) => <div key={idx} className="flex justify-between items-center"><span className="font-bold opacity-80">{i.name} × {i.quantity}</span><span className="font-black text-[#3d2b1f]">{i.price * i.quantity} ر.ق</span></div>)}
          </div>
          <div className="pt-2 flex justify-between items-center text-[#3d2b1f]"><span className="text-[10px] font-black opacity-50">إجمالي الطلب:</span><span className="text-lg font-black">{o.total} ر.ق</span></div>
          {['admin', 'cashier'].includes(userRole) && (
             <div className="flex gap-4 pt-4 border-t border-gray-50">
                {o.status === 'received' && (
                  <>
                    <Button onClick={() => onUpdateStatus(o.id, 'rejected')} variant="danger" className="flex-grow py-4 text-xs rounded-2xl">رفض</Button>
                    <Button onClick={() => onUpdateStatus(o.id, 'preparing')} className="flex-grow py-4 text-xs rounded-2xl">قبول</Button>
                  </>
                )}
                {o.status === 'preparing' && <Button onClick={() => onUpdateStatus(o.id, 'ready')} variant="secondary" className="w-full py-4 text-xs rounded-2xl">جاهز للاستلام</Button>}
                {o.status === 'ready' && <Button onClick={() => onUpdateStatus(o.id, 'delivered')} className="w-full py-4 text-xs rounded-2xl">تم التسليم</Button>}
             </div>
          )}
        </div>
      ))
    )}
  </div>
);

const ScannerPage: React.FC<{ onProcessAction: (type: 'stamp' | 'redeem', phone: string, val: number) => void }> = ({ onProcessAction }) => {
  const [phone, setPhone] = useState('');
  const [amount, setAmount] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const simulateScan = () => {
    setIsScanning(true);
    setTimeout(() => { setIsScanning(false); setPhone('55551111'); alert('✅ تم التعرف على الكود الرقمي للعميل'); }, 2000);
  };
  return (
    <div className="p-10 space-y-10 pb-32">
      <div onClick={simulateScan} className="w-full aspect-square bg-[#1a110a] rounded-[64px] border-[10px] border-[#c5a059] flex items-center justify-center relative overflow-hidden shadow-2xl cursor-pointer active:scale-95 transition-all group">
        {isScanning && <div className="scanner-line"></div>}
        <div className="absolute inset-0 border-[80px] border-black/60 pointer-events-none"></div>
        <div className="z-20 flex flex-col items-center gap-5">
          <Camera className={`w-32 h-32 transition-all duration-700 ${isScanning ? 'text-[#c5a059] scale-110 rotate-12' : 'text-[#c5a059]/20'}`} />
          <p className="text-[#c5a059] text-[11px] font-black tracking-[5px] uppercase animate-pulse">{isScanning ? 'جارِ التحليل...' : 'اضغط للمسح الضوئي'}</p>
        </div>
      </div>
      <div className="bg-white p-10 rounded-[56px] shadow-2xl border-2 border-[#f5e6d3] space-y-8">
        <div className="space-y-5">
          <div className="relative group">
            <Phone className="absolute left-6 top-1/2 -translate-y-1/2 text-[#c5a059] w-6 h-6 opacity-40 group-focus-within:opacity-100 transition-opacity" />
            <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="رقم الهاتف" className="w-full p-6 pl-16 border-2 border-[#f5e6d3] rounded-[28px] shadow-inner outline-none font-black text-xl text-center" />
          </div>
          <div className="relative group">
            <span className="absolute left-6 top-1/2 -translate-y-1/2 text-[#3d2b1f] font-black opacity-30">ر.ق</span>
            <input value={amount} onChange={e => setAmount(e.target.value)} type="number" placeholder="قيمة العملية" className="w-full p-6 pl-20 border-2 border-[#f5e6d3] rounded-[28px] font-black text-3xl text-[#3d2b1f] shadow-inner outline-none text-center" />
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <Button onClick={() => { onProcessAction('stamp', phone, parseFloat(amount)); setPhone(''); setAmount(''); }} variant="primary" className="py-6 text-xl rounded-[28px]">تأكيد العملية</Button>
          <Button onClick={() => { onProcessAction('redeem', phone, 0); setPhone(''); }} variant="secondary" className="py-6 text-xl rounded-[28px]">تسليم المكافأة</Button>
        </div>
      </div>
    </div>
  );
};
